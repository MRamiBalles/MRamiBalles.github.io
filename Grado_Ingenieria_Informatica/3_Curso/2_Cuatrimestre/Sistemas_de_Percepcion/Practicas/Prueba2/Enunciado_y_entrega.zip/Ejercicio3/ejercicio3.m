%% Ejercicio 3 - Calculo y representacion de datos esferas de agrupaciones

