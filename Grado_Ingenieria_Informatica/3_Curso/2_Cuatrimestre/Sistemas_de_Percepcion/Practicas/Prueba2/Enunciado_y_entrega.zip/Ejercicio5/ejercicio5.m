%% Ejercicio 5 - Aplicación de algoritmo de clasificacion en imagen de test


