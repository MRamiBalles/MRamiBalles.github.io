%% Ejercicio 2 - apartado Extracci�n de datos- Representacion de datos
