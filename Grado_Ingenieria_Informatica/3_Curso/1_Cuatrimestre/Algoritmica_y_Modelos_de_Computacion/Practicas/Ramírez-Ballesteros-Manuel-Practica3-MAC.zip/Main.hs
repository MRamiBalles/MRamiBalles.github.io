module Main 
( main
) where

import Busqueda
import Auxiliar
import System.Info
import System.Process
import Data.List (nub)

main :: IO()
main = do
	putStrLn ""
	cls
	putStrLn "Alumno : Manuel Ramirez Ballesteros"
	putStrLn "-------------------------------------"
	putStrLn ""
	putStrLn "Piensa un numero.."
	putStrLn ".."
	putStrLn ".."
	putStrLn "-------------------------------------"
	putStrLn ""
	putStrLn "Tipos de busqueda : "
	putStrLn "1 - Busqueda secuencial"
	putStrLn "2 - Busqueda binaria"
	putStrLn "3 - Busqueda por interpolacion"
	putStrLn "4 - Salir"
	putStrLn ""
	putStrLn "Escriba la opcion que desee :"
	t <- getLine
	putStrLn ""
	case t of	
		"1" -> do
			putStrLn "Ingrese el vector de elementos en el que desea buscar su numero separados por espacios : "
			vec <- getLine
			let v = nub $ convertirVector vec
			putStrLn $ "El vector ingresado es = " ++ show v
			busqueda_secuencial v
			main
		"2" -> do
			putStrLn "Ingrese el vector de elementos en el que desea buscar su numero separados por espacios : "
			vec <- getLine
			let v = nub $ quicksort $ convertirVector vec
			busqueda_binaria v
			main
		"3" -> do
			putStrLn "Ingrese el vector de elementos en el que desea buscar su numero separados por espacios : "
			vec <- getLine
			let v = nub $ quicksort $ convertirVector vec
			busqueda_interpolacion v
			main
		"4" -> do 
			putStrLn "¡Fin del juego!"
			putStrLn ""
			return ()
		_ -> do
			putStrLn "Error : Opcion no disponible.."
			putStrLn "Pulse cualquier tecla para continuar.."
			getLine
			main
	-- ghc -o nombre fich.hs
	-- Para borrar pantalla cls -> Importar modulo System.Info y  System.Process -> cls = putStr "\ESC[J"
	-- :q para salir de ghci
	-- Procedimiento : Abrir directorio con ficheros, ghci, :l main, menu