module Auxiliar
( cls
, quicksort
, convertirVector
, elementoCerca
) where

cls :: IO()
cls = putStr "\ESC[2J"


quicksort :: (Ord a) => [a] -> [a]
quicksort [] = []
quicksort [x] = [x]
quicksort (c : r) = quicksort (filter (\y -> y <= c) r) ++ [c] 
    ++ quicksort (filter (\y -> y > c) r)


convertirVector :: String -> [Int]
convertirVector = map read . words

elementoCerca :: [Int] -> Int -> Int
elementoCerca a b = 
    foldl(\t x -> if abs (x - b) < abs (t - b) then x else t) (head a) a