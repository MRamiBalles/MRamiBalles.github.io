module Busqueda 
( busqueda_secuencial
, busqueda_binaria
, busqueda_interpolacion
) where

import Auxiliar

busqueda_secuencial :: [Int] -> IO ()
busqueda_secuencial (c:r) = do
	if r == [] then do
			putStrLn $ "¿Su numero es : " ++ show c ++ "?"
			res <- getLine
			if res == "NO" then do
					putStrLn "El numero pensado no parece estar en la lista.. Pruebe a jugar de nuevo.."
					putStrLn "Pulse cualquier tecla para continuar : "
					x <- getLine
					putStrLn ""
			else if res == "SI" then do
					putStrLn "¡Numero acertado!"
					putStrLn "Pulse cualquier tecla para continuar : "
					x <- getLine
					putStrLn ""
			else do 
				putStrLn "Respuesta incorrecta : SI o NO"
				putStrLn ""
				busqueda_secuencial (c:r)
	else do	
			putStrLn $ "¿Su numero es : " ++ show c ++ "?"
			res <- getLine
			if res == "NO" then 
				busqueda_secuencial r
			else if res == "SI" then do 
				putStrLn ""
				putStrLn "¡Numero acertado!"
				putStrLn ""
				putStrLn "Pulse cualquier tecla para continuar : "
				x <- getLine
				putStrLn ""
			else do 
				putStrLn ""
				putStrLn "Respuesta incorrecta : SI o NO"
				putStrLn ""
				busqueda_secuencial (c:r)
	
busqueda_binaria :: [Int] -> IO ()
busqueda_binaria [] = do
	putStrLn "La lista esta vacia. ¡Fin del juego!"
	putStrLn ""
	putStrLn "Pulse cualquier tecla para continuar : "
	x <- getLine
	putStrLn ""
	
busqueda_binaria l = do
	putStrLn $ "El vector ingresado es = " ++ show l
	let long = length l
	let medio = div long 2
	let elem = l !! medio
	putStrLn $ "¿Su numero es : " ++ show elem ++ "?"
	respuesta <- getLine
	case respuesta of
		"NO" -> do
			putStrLn $ "¿Su numero es mayor que " ++ show elem ++ "?"
			res <- getLine
			if res == "SI" then
					busqueda_binaria (drop (medio + 1) l)
			else if res == "NO" then
					busqueda_binaria (take medio l)
			else do 
					putStrLn ""
					putStrLn "La respuesta debe ser: SI o NO"
					busqueda_binaria l
		"SI" -> do
			putStrLn ""
			putStrLn "¡Numero acertado!" 
			putStrLn "Pulse cualquier tecla para continuar : "
			x <- getLine
			putStrLn ""
		_ -> do 
			putStrLn ""
			putStrLn $ "Respuesta incorrecta : SI o NO"
			putStrLn ""
			busqueda_binaria l
			
		
busqueda_interpolacion :: [Int] -> IO ()
busqueda_interpolacion [] = do
	putStrLn "La lista esta vacia. ¡Fin del juego!"
	putStrLn ""
	putStrLn "Pulse cualquier tecla para continuar : "
	x <- getLine
	putStrLn ""

busqueda_interpolacion l = do	
	putStrLn $ "El vector ingresado es = " ++ show l
	let media = div (sum l) (length l) 
	let elem = elementoCerca l media
	putStrLn $ "¿Su numero es : " ++ show elem ++ "?"
	respuesta <- getLine
	if respuesta == "NO" then do
			putStrLn $ "¿Su numero es mayor que " ++ show elem ++ "?"
			res <- getLine
			putStrLn ""
			if res == "SI" then do
					busqueda_interpolacion (dropWhile (<= elem) l) 
			else do 
					busqueda_interpolacion (takeWhile (/= elem) l)
	else if respuesta == "SI" then do
			putStrLn ""
			putStrLn "¡Numero acertado!" 
			putStrLn ""
			putStrLn "Pulse cualquier tecla para continuar : "
			x <- getLine
			putStrLn ""
	else do 
			putStrLn ""
			putStrLn "Respuesta incorrecta : SI o NO"
			putStrLn ""
			busqueda_interpolacion l